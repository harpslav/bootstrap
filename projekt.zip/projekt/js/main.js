const links = $("a:not([href='#'])");
const body = $("body");
const scrollTime = 600;

function navigation(e) {
    e.preventDefault();
    links.removeClass('active');
    $(this).addClass("active");

    let targetElement = $(this.hash);
    $("html, body").animate({scrollTop: targetElement.offset().top},scrollTime);
}

function scrollWindow() {
    if( $(window).scrollTop() > 20 ) {
        body.addClass("move");
    } else {
        body.removeClass("move");
    }
}

links.on("click", navigation);
$(window).on("scroll", scrollWindow);

